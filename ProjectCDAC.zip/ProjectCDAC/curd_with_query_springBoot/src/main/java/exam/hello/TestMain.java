package exam.hello;

import java.util.Collection;
import java.util.List;

import org.springframework.web.client.RestTemplate;

public class TestMain {
	public static void main(String[] args) {
		String url ="http://localhost:8080";
		RestTemplate t =new RestTemplate();
		//Customer xx = t.getForObject(url+"/ssq?x=999", Customer.class);
     	 // System.out.println(xx);
		
//		  Collection<Account> xxx = t.getForObject(url+"/msq?x=3000", Collection.class);
//		  System.out.println(xxx);
		  
		 // Guide zz =new  Guide(10,0,"hhh","city");
		 // Guide a = t.postForObject("http://localhost:8080/upq", zz, Customer.class);
		
		

	}

}
